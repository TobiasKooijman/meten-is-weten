var1 = input("    geef de waarde van a ")
var2 = input("    geef de waarde van b ")




print("")
print("---------------------------------------------------------------------->")
print("")

if var1 > var2:
    print("    a is het grootste getal")

