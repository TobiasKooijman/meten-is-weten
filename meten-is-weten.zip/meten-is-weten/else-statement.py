var1 = input("    geef de waarde van a ")
var2 = input("    geef de waarde van b ")




print("")
print("---------------------------------------------------------------------->")


if var2 > var1:
    print("    a is het kleinste getal")

if var2 < var1:
    print("    a is het grootste getal")

